import openai
import requests
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from db import get_connection

mensagem_bp = Blueprint('mensagem', __name__)

# ✅ Configuração da OpenAI API
# OPENAI_API_KEY = "" #colocar a chave privada aqui
# OPENAI_MODEL = "gpt-4"  # 🔹 Escolha "gpt-3.5-turbo" se necessário

# openai.api_key = OPENAI_API_KEY  # Configura a API Key

# ---------------------------
# ✅ Enviar mensagem e obter resposta da OpenAI
# ---------------------------
@mensagem_bp.route('/mensagens', methods=['POST'])
@jwt_required()
def enviar_mensagem():
    usuario_id = get_jwt_identity()
    data = request.json
    chat_id = data.get('idchat')
    conteudo = data.get('conteudo')

    if not conteudo or not chat_id:
        return jsonify({'message': 'Chat ID e conteúdo são obrigatórios'}), 400

    conn = get_connection()
    cursor = conn.cursor()

    try:
        # 1️⃣ Salvar a mensagem do usuário no banco
        cursor.execute("INSERT INTO mensagem (conteudo, origem, enviado_em, idusuario, idchat) VALUES (%s, 'usuario', NOW(), %s, %s)",
                       (conteudo, usuario_id, chat_id))
        conn.commit()

        # 2️⃣ Enviar a mensagem para a OpenAI
        resposta_llm = obter_resposta_da_llm(conteudo)

        # 3️⃣ Salvar a resposta da OpenAI no banco
        cursor.execute("INSERT INTO mensagem (conteudo, origem, enviado_em, idusuario, idchat) VALUES (%s, 'sistema', NOW(), %s, %s)",
                       (resposta_llm, usuario_id, chat_id))
        conn.commit()

        return jsonify({'message': 'Mensagem enviada!', 'resposta': resposta_llm}), 201

    except Exception as e:
        conn.rollback()
        print("❌ ERRO NO BACKEND:", str(e))  # 🔹 Exibe erro no terminal
        return jsonify({'message': 'Erro ao processar mensagem', 'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# ---------------------------
# ✅ Função para chamar a API do ChatGPT (OpenAI)
# ---------------------------
def obter_resposta_da_llm(mensagem_usuario):
    try:
        resposta = openai.ChatCompletion.create(
            # model=,
            messages=[{"role": "user", "content": mensagem_usuario}],
            max_tokens=300
        )

        print("Resposta completa da OpenAI:", resposta)  # Debug

        return resposta["choices"][0]["message"]["content"].strip()

    except openai.AuthenticationError:
        return "Erro: Chave de API inválida. Verifique sua OpenAI API Key."

    except openai.RateLimitError:
        return "Erro: Você atingiu o limite de requisições da OpenAI. Tente novamente mais tarde."

    except openai.APIConnectionError:
        return "Erro: Problema de conexão com a API da OpenAI."

    except Exception as e:
        print("❌ ERRO NA OPENAI:", str(e))  # Debug no console
        return f"Erro ao conectar com a LLM (OpenAI): {str(e)}"


# ---------------------------
# ✅ Listar mensagens de um chat específico
# ---------------------------
@mensagem_bp.route('/mensagens/<int:chat_id>', methods=['GET'])
@jwt_required()
def listar_mensagens(chat_id):
    usuario_id = get_jwt_identity()

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute(
            "SELECT * FROM mensagem WHERE idchat = %s ORDER BY enviado_em ASC",
            (chat_id,)
        )
        mensagens = cursor.fetchall()

        return jsonify({'mensagens': mensagens}), 200

    except Exception as e:
        return jsonify({'message': 'Erro ao recuperar mensagens', 'error': str(e)}), 500

    finally:
        cursor.close()
        conn.close()

